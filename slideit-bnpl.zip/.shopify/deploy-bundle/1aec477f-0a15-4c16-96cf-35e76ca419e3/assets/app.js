(function () {
  const isProductPage = window.location.pathname.includes('/products/');
  const isCartPage = window.location.pathname.includes('/cart');

  const injectButton = () => {
    const button = document.createElement('button');
    button.innerText = 'Pay with SlideIt';
    button.style = `
      background-color: #1e40af;
      color: white;
      padding: 10px 16px;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      margin-top: 16px;
      cursor: pointer;
    `;

    button.onclick = async () => {
      const payload = isCartPage
        ? await fetch('/cart.js').then(res => res.json())
        : {
            product: document.querySelector('h1')?.innerText || 'Unknown Product',
            price: document.querySelector('[data-product-price]')?.innerText || '',
          };

      const params = new URLSearchParams({
        data: JSON.stringify(payload),
      });

      window.location.href = `/apps/slideit/redirect?${params.toString()}`;
    };

    const target = document.querySelector('form[action^="/cart"]') ||
                   document.querySelector('form[action^="/cart/add"]');

    if (target) target.appendChild(button);
  };

  window.addEventListener('DOMContentLoaded', injectButton);
})();
