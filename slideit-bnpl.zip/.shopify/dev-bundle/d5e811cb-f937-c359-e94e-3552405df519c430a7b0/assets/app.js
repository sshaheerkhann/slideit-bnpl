(function () {
  window.addEventListener("DOMContentLoaded", async () => {
    const button = document.querySelector("#slideit-main-button");

    // Function to calculate installments
    async function calculateInstallments() {
      let totalPrice = 0;

      if (window.location.pathname.includes("/cart")) {
        const res = await fetch("/cart.js");
        const cart = await res.json();
        totalPrice = cart.total_price / 100;
      } else {
        const price =
          document
            .querySelector("[itemprop='price']")
            ?.getAttribute("content") ||
          document.querySelector(".price-item--regular")?.innerText ||
          "0";
        totalPrice = Number(price);
      }

      if (totalPrice > 0) {
        const installment = (totalPrice / 3).toFixed(2);
        document.getElementById("slideit-installment-1").innerText = `PKR ${installment}`;
        document.getElementById("slideit-installment-2").innerText = `PKR ${installment}`;
        document.getElementById("slideit-installment-3").innerText = `PKR ${installment}`;
      }
    }

    // Run once on page load
    calculateInstallments();

    // Handle button click
    button.addEventListener("click", async () => {
      const buyerName = window._slideitCustomer?.name || "Unknown";
      const buyerEmail = window._slideitCustomer?.email || "";
      let payload = {};

      if (window.location.pathname.includes("/cart")) {
        const res = await fetch("/cart.js");
        const cart = await res.json();
        payload = {
          items: cart.items.map((item) => ({
            productId: item.product_id,
            variantId: item.variant_id,
            title: item.product_title,
            quantity: item.quantity,
            price: item.final_line_price / 100,
          })),
          totalPrice: cart.total_price / 100,
          buyerName,
          buyerEmail,
        };
      } else {
        const productTitle =
          document.querySelector("h1")?.innerText || "Unknown Product";
        const price =
          document
            .querySelector("[itemprop='price']")
            ?.getAttribute("content") ||
          document.querySelector(".price-item--regular")?.innerText ||
          "0";

        payload = {
          items: [{ title: productTitle, quantity: 1, price: Number(price) }],
          totalPrice: Number(price),
          buyerName,
          buyerEmail,
        };
      }

      console.log("🟢 SlideIt Payload:", payload);

      const url = new URL(
        "https://polls-fairy-attractive-presidential.trycloudflare.com/apps/slideit/redirect"
      );
      url.searchParams.set("data", JSON.stringify(payload));
      window.location.href = url.toString();
    });
  });
})();
