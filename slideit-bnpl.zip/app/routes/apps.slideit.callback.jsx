import { json } from "@remix-run/node";
import prisma from "../db.server"; // adjust the path if needed

export const action = async ({ request }) => {
  try {
    const payload = await request.json();
    console.log("📦 SlideIt callback payload:", payload);

    const {
      productTitle,
      price,
      buyerName,
      buyerEmail,
      shopEmail,
      orderId,
      status,
    } = payload;

    if (!orderId || !productTitle || !price || !buyerEmail) {
      return json({ error: "Missing required fields" }, { status: 400 });
    }

    await prisma.slideitOrder.create({
      data: {
        trackingId: orderId,
        productTitle,
        price: String(price),
        status: status === true ? "approved" : "rejected",
        raw: payload, // Store full callback payload for reference
      },
    });

    return json({ success: true });
  } catch (err) {
    console.error("❌ Error in SlideIt callback:", err);
    return json({ error: "Failed to process callback" }, { status: 500 });
  }
};
